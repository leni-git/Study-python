# -*- coding:utf-8 -*-

# socket을 사용하기 위한 python module import
from socket import *
from data_file import *
from aestest import *

import pickle
import struct, os


ssock=socket(AF_INET, SOCK_STREAM)
ssock.bind(SocketInfo.ADDR)
ssock.listen(5)
csock=None

def sendCommend(string):
    csock.send(string.encode())

def sendByte(byte):
    csock.send(byte)

def recvCommend():
    return csock.recv(SocketInfo.BUFSIZE).decode()

try:
    while True :

        if csock is None :

            print "waiting for connection..."
            csock, addr_info = ssock.accept()

            sendCommend("START")
            commend=recvCommend()

            if commend=="SEND_DATA" :


                FILE_SIZE = os.path.getsize("file.txt")
                FILE_SIZE = struct.pack('L', FILE_SIZE)
                csock.send(FILE_SIZE)

                with open("file.txt", "rb") as output_file :
                    data = output_file.read()

                    while data:
                        sendByte(data)
                        data = output_file.read(SocketInfo.BUFSIZE)

            # 파일을 보낸다. 코드와 함께 영화 저장정보를 1차로 전송한다.
            print "Send data to > ", addr_info
            print ""

        else:

            print "waiting for response..."
            commend=recvCommend()
            print "accept >> "+commend
            print ""

except Exception, KeyboardInterrupt:
    csock.close()