# -*- coding:utf-8 -*-

# 이상한 번호를 입력하는지 체크
def choice(c, max):

    print " c choice : ", c
    print " len menu : ", str(max)
    if len(c)!=1 or int(c)<0 or int(c)>max:
        print "\n★ ★ ★ what? 다시 선택해 주세요. ★ ★ ★\n\n"
        return False
    else : return int(c)-1



def choice_Movie(chM, chMT, movieList):

    chN=0

    for i in range(len(movieList)) :
        if chM==movieList[i].mName :
            chN=i
            break
        else : chN="False"

    try:
        chT=movieList[chN].mTime.index(chMT)
    except : chT="False"

    # 리스트 안에 있으면 참 없으면 거짓
    return str(chN), str(chT)
