# -*- coding:utf-8 -*-

# 기본적인 선택에러는 전부 Client에서 처리하도록 한다.
