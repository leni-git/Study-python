# -*- coding:utf-8 -*-

from print_file import *
from error_check import *

class Method() :

    def MovieSystemStart(self, movieList) :

        while True :
            ch=choice(menu(), 5)+1
            if ch!=False :

                if ch == 3:
                    # 영화 관리
                    while True:
                        try:

                            print """\n- - - - - - - - - - - - - - - - - -
     1. 상영영화 추가
     2. 상영영화 수정
     3. 상영영화 삭제
     4. 메인으로 돌아가기
- - - - - - - - - - - - - - - - - -"""
                            ch3 = input("  >> ")

                            if ch3 == 1:
                                print "- - - - - - - - - - - - - - - - - - "
                                name = raw_input(" + name : ")
                                movie = None
                                for i in range(len(movieList)):
                                    if movieList[i].mName == name: movie = i

                                if movie == None:
                                    number = input(" + number : ")
                                    times= raw_input(" + time : ")
                                    return ch, ch3, number, name, times
                                else:
                                    # 상영하고있는 영화라면 상영관번호는 받지않고 상영시간만 추가한다.
                                    # 시간만 추가받고나면 정렬을 다시해준다 sort()
                                    times = raw_input(" + time : ")
                                    return ch, ch3, movie, times

                            # 수정
                            # 영화목록을 띄워주고 선택하게 한다.
                            # 영화에 대한 정보가 뜨고 상영관, 상영시간을 수정가능하도록 한다.
                                    # 종료, 메인으로 돌아감
                            elif ch3 == 4: break
                            else :
                                if len(movieList)==0 :   print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""

                                else :
                                    if ch3 == 2:
                                        print "\n- - - - - - - - - - - - - - - - - - "

                                        for i in range(len(movieList)):
                                            print " " + str(i + 1) + ". " + movieList[i].mName
                                        print "- - - - - - - - - - - - - - - - - - "
                                        name = choice(raw_input(" >> "), movieList[i].mName)
                                        if name!=0 and not name :
                                            print "\n★ ★ ★ what? 다시 선택해 주세요 ★ ★ ★\n\n"
                                            continue
                                        else:
                                            # 영화정보 띄워주기 이름, 상영관, 상영시간
                                            print "\n- - - - - - - - - - - - - - - - - - "
                                            print """ 수정을 원하시는 시간을 선택해주세요.
        영화 상영시간만 수정하실 수 있습니다.\n"""
                                            print " - name : " + movieList[name].mName
                                            print " - number : " + str(movieList[name].mRoom)
                                            print " - times\n   ",
                                            for i in range(len(movieList[name].mTime)):
                                                if i % 3 == 0 and i != 0: print ""
                                                print movieList[name].mTime[i] + " ",
                                            print "\n- - - - - - - - - - - - - - - - - - "
                                            bef = raw_input(" >> 선택할 시간 : ")
                                            # Try - catch 로 잡아줘야...
                                            i = movieList[name].mTime.index(bef)
                                            if i + 1:
                                                time = raw_input(" >> 변경할 시간 : ")
                                                return ch, ch3, name, i, time
                                            else:
                                                "\n★ ★ ★ what? 다시 시도해 주세요 ★ ★ ★\n\n"
                                            # 수정할것선택하게해야하자낭라나어리ㅏ 으어어어어어

                                # 삭제
                                # 영화목록을 띄워주고 선택하게해서 삭제한다.
                                    elif ch3 == 3:
                                        print "\n- - - - - - - - - - - - - - - - - - "
                                        for i in range(len(movieList)):
                                            print " " + str(i + 1) + ". " + movieList[i].mName
                                        print "- - - - - - - - - - - - - - - - - - "
                                        name = choice(raw_input(" >> "), len(movieList[i].mName))
                                        if name!=0 and not name :
                                            print "\n★ ★ ★ what? 다시 선택해 주세요 ★ ★ ★\n\n"
                                            continue
                                        else:
                                            return ch, ch3, name
                                            # pop 말고 삭제시키는건 없나? del!!!!!!
                                            #del movieList[name]

                        except:
                            print "\n★ ★ ★ what? 다시 선택해 주세요 ★ ★ ★\n\n"
                            continue

                elif ch == 5: return '0', ch

                else :

                    if len(movieList) == 0:
                        print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""

                    else :
                        if ch==1 or ch==2 :
                            # 영화 예매 선택 및, 영화 상영시간 확인
                            while True :
                                movie, time = PrintMovie(movieList)
                                movie, time = choice_Movie(movie, time, movieList)
                                if movie==False or time==False :
                                    print "\n★ ★ ★ what? 다시 선택해 주세요. ★ ★ ★\n\n"
                                    continue
                                else :
                                    movie, time = int(movie), int(time)
                                    if ch == 2:
                                        PrintSeat(movieList[movie].mTotalSeat[time])
                                        break
                                    elif ch==1 :
                                        while True :
                                            try:
                                                co1=input("\n어린이 >> ")
                                                co2=input("청소년 >> ")
                                                co3=input("어른 >> ")

                                                count=co1+co2+co3

                                                movieList[movie].mTotal=co1*5000 + co2*6000 + co3*8000
                                            except:
                                                print "\n★ ★ ★ what? 다시 선택해 주세요. ★ ★ ★\n\n"
                                                continue

                                            print "len movieList Seat : ", len(movieList[movie].mTotalSeat)

                                            PrintSeat(movieList[movie].mTotalSeat[time])
                                            temp=raw_input(" - 좌석을 선택해 주세요.\n - 좌석의 구분은 스페이스로 해주세요. ex) A1 A2 A3\n\t >> ")
                                            temp=temp.split()
                                            # 인원 확인하는 부분 넣을 것.
                                            # A-E, 1-5가 범위 넘어가면 다시 선택, count 안 맞으면 다시 선택. 스페이스로 구분
                                            if(count>len(temp)) :
                                                print "\n★ ★ ★ 관람인원보다 작은 좌석을 선택하셨습니다. 다시 입력해주세요. ★ ★ ★\n"
                                                continue
                                            elif(count<len(temp)) :
                                                print "\n★ ★ ★ 관람인원보다 많은 좌석을 선택하셨습니다. 다시 입력해주세요. ★ ★ ★\n"
                                                continue
                                            else:
                                                while True :
                                                    print "\n총 결제 금액은 ",  movieList[movie].mTotal, "원 입니다."
                                                    ch_money=raw_input("결제하시겠습니까? (yes/no) >> ")
                                                    seats=""
                                                    for i in range(len(temp)) :
                                                        if i==(len(temp)-1) : seats+=temp[i]
                                                        else : seats+=(temp[i]+", ")
                                                    print ch_money
                                                    if(ch_money=="yes") : return ch, movie, time, seats
                                                    elif(ch_money=="no") :
                                                        "\n★ ★ ★ 결제가 취소 되었습니다, 초기화면으로 돌아갑니다. ★ ★ ★\n"
                                                        return '0', ch
                                                    else :
                                                        "잘못입력하셨습니다."
                                                        continue


                        elif ch == 4 :
                            # 총 수입확인
                            print "\n- - - - 영화 총 수입 입니다 - - - -"
                            result = 0
                            for i in range(len(movieList)):
                                print "  \"%-10s\" ic : %10d won" % (movieList[i].mName, movieList[i].mTotal)
                                result += movieList[i].mTotal
                            print "- - - - - - - - - - - - - - - - - -"
                            print "     Total >> " + str(result)
                            print "- - - - - - - - - - - - - - - - - -"

            else : pass

    def SeatView(self, movieList) : PrintSeat(movieList)



