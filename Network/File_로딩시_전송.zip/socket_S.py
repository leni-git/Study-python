# -*- coding:utf-8 -*-

# socket을 사용하기 위한 python module import
from socket import *
from data_file import *

import pickle
import struct, os


ssock=socket(AF_INET, SOCK_STREAM)
ssock.bind(SocketInfo.ADDR)
ssock.listen(5)
csock=None

fssock = socket(AF_INET, SOCK_STREAM)
fssock.bind(SocketInfo.FADDR)
fssock.listen(5)
fsock = None

f=open("movielist.bin", 'wb+')
test=MInfo(1, "spi", ["01:30", "02:30", "06:00"])
test2=MInfo(2, "abc", ["02:00"])
movietest=[test, test2]
print "len movielist : ", len(movietest)
print "len movieList 0 Seat : ", len(movietest[0].mTotalSeat)
print "len movieList 1 Seat : ", len(movietest[1].mTotalSeat)
pickle.dump(movietest, f)
f.close()

movieList=None

def sendCommend(string): csock.send(string.encode())
def sendByte(byte): csock.send(byte)

def recvCommend():
    temp=csock.recv(SocketInfo.BUFSIZE).decode()
    return temp.split("# ")

try:
    while True :

        if csock is None :

            print "waiting for connection..."
            csock, addr_info = ssock.accept()

            sendCommend("MOVIE_INFO")
            print "connect data to > ", addr_info
            # 파일을 보낸다. 코드와 함께 영화 저장정보를 1차로 전송한다.

        else:

            print "waiting for response..."
            commend = recvCommend()

            if commend==0 : csock.close()
            else :
                print "accept >> ", commend
                print ""

                if commend[0] == "MOVIE_INFO_READY":

                    fsock, faddr_info = fssock.accept()

                    f = open("movielist.bin", "rb")
                    movieList=pickle
                    data = f.read()

                    FILE_SIZE = os.path.getsize("movielist.bin")
                    FILE_SIZE = struct.pack('L', FILE_SIZE)
                    fsock.send(FILE_SIZE)

                    while data:
                        fsock.send(data)
                        data = f.read(SocketInfo.BUFSIZE)

                    f.close()
                    print "Send data to > > > > > ", faddr_info
                    fsock.close()
                    print "close"

                elif commend[0]=="CLIENT_START_READY" :
                    sendCommend("MOVIE_SYSTEM_START")

                elif commend[0]=="CLIENT_MOVIE_CHOICE" :
                    mtch=commend[1].split("# ")
                    seats=commend[2].split(", ")

                    # 선택한 영화에 대한 정보를 저장한다.
                    pass

                else:
                    sendCommend("MOVIE_INFO")

except Exception as e:
    print "%s:%s" % (e, SocketInfo.ADDR)
    csock.close()
