# -*- coding:utf-8 -*-

from socket import  *
from sys import exit
from method_C import *
from data_file import *

import struct
import pickle

class SocketInfo(SocketInfo) :
    HOST='127.0.0.1'

movieList=[]
method=Method()
FILE_LEN=0

def sendCommend(string): csock.send(string.encode())

def recvCommend():
    temp=csock.recv(SocketInfo.BUFSIZE).decode()
    return temp.split("# ")

def recvByte(): return csock.recv(SocketInfo.BUFSIZE)

csock = socket(AF_INET, SOCK_STREAM)
csock.connect(SocketInfo.ADDR)


try:
    while True:

        commend = recvCommend()
        print " >> server say : ", commend

        if commend[0]=="MOVIE_INFO" :
            sendCommend("MOVIE_INFO_READY")
            print "- - - - - - - - - - - - - - - - - in MOVIE, wait data response"

            fsock = socket(AF_INET, SOCK_STREAM)
            fsock.connect(SocketInfo.FADDR)

            FILE_SIZE = fsock.recv(8)
            FILE_SIZE = struct.unpack('L', FILE_SIZE)[0]

            # file open -----------------------------------------------------------------------------------------------------
            f = open("movielistTemp.bin", "wb+")

            while True:
                data = fsock.recv(SocketInfo.BUFSIZE)
                if not data: break

                f.write(data)
                FILE_LEN += len(data)
                if FILE_LEN == int(FILE_SIZE): break

            f.close()
            fsock.close()
            # file close -----------------------------------------------------------------------------------------------------
            sendCommend("CLIENT_START_READY")

        elif commend[0]=="MOVIE_SYSTEM_START":

            # file open -----------------------------------------------------------------------------------------------------
            f = open("movielistTemp.bin", "r")
            movieList = pickle.load(f)
            f.close()
            # file close -----------------------------------------------------------------------------------------------------

            inside=method.MovieSystemStart(movieList)
            print inside

            if inside[0]=='0':
                if inside[1]==1 : sendCommend("CANCEL_PAY")
                elif inside[1]==5 : break

            elif inside[0]==1:
                sendCommend("CLIENT_MOVIE_CHOICE# "+str(inside[1])+", "+str(inside[2])+"# "+inside[3])

            elif inside[0]==3:
                if inside[1]==1:
                    if len(inside)==5: sendCommend("CLIENT_MOVIE_ADD# "+str(inside[2])+", "+inside[3]+"# "+inside[4])
                    elif len(inside)==4: sendCommend("CLIENT_MOVIE_ADD# "+str(inside[2])+"# "+inside[3])

                elif inside[1]==2:
                    sendCommend("CLIENT_MOVIE_CHANGE# "+str(inside[2])+", "+str(inside[3])+", "+inside[4])

                elif inside[1]==3:
                    sendCommend("CLIENT_MOVIE_DEL# "+str(inside[2]))

            else :
                print "System error"
                break

    print "System OFF"
    csock.close()
    exit()

    print "---------------------------"

except Exception as e :
    print "%s:%s" %(e, SocketInfo.ADDR)
    csock.close()
    exit()




