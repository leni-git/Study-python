# -*- coding:utf-8 -*-

from print_file import *
from data_file import *

# 기능에 따른 동작 구현
class Method():

    def Book(self, mInfo):

        # 영화집합 가져오기 및 영화제목만 출력
        if mInfo==[]: print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""

        # else의 입장에서 for 다음에 오는 문장은 2번째에 해당하는 줄이니까 밑으로 내려줘야한다!
        else:
            print "\n- - - - 영화를 선택해주세요 - - - - "
            for i in range(0, len(mInfo)) : print "        "+str(i+1)+". "+mInfo[i].mName
            print "- - - - - - - - - - - - - - - - - - "
            choice=raw_input("  >> ")

            if(len(choice)!=1): print "\n★ ★ ★ what? 초기 화면으로 갑니다 ★ ★ ★\n\n"
            else:
                choice=int(choice)-1
                if choice<0 or choice>(len(mInfo)-1):
                    print "\n★ ★ ★ what? 초기 화면으로 갑니다 ★ ★ ★\n\n"
                else:
                    print "\n- - - - - "+mInfo[choice].mName+" 상영 시간 - - - - - "
                    print """\n>> 상영시간을 다음과 같은 형식으로 선택해주세요.
01시30분 영화를 보고싶으시면 01:30 이라고 입력해주세요.\n\n"""
                    for i in range(len(mInfo[choice].mTime)): print "%s" %mInfo[choice].mTime[i],
                    print "\n- - - - - - - - - - - - - - - - - -"
                    chTime=raw_input("  >> ")
                    # 에러 try- catch
                    chTime=mInfo[choice].mTime.index(chTime)

                    print "\n- - - 관람 인원을 입력해주세요 - - -"
                    adult=input("   >> 어른 : ")
                    teen=input("   >> 청소년 : ")
                    child=input("   >> 어린이 : ")
                    total=adult*8000+teen*7000+child*5000
                    count=adult+teen+child
                    if count==0 : print " >> 관람 인원을 잘못 입력하셨습니다.\n >> 초기화면으로 돌아갑니다. 감사합니다."
                    else:
                        print "\n >> 총 합계 : "+str(total)+"원 입니다."
                        print " >> 결제하시겠습니까? (yes/no)"

                        if(raw_input(" >> ")=="yes"):
                            mInfo[choice].mTotal+=total
                            print "\n- - - 앉을 좌석을 선택해주세요 - - -"
                            PrintSeat(mInfo[choice].mTotalSeat[chTime]).PrintSeat()

                            print """\n>> 앉을 좌석을 다음과 같은 형식으로 선택해주세요.
A행에 1열에 앉고 싶으시면 A1
여러명이 좌석의 예약할 때는 사람수만큼 좌석번호를 하나씩 입력해주세요.\n"""
                            for i in range(count):
                                seat=raw_input("    >> ")
                                i=seat[0]
                                j=int(seat[1])
                                # 튜플에 좌석정보 저장해서 넘겨주는 것으로 이미 예약한 좌석 중복예약 금지시키기.
                                # continue, tuple list [( , ), ... ] count 수만큼 받기 확인되면 넘겨서 저장하기.
                                mInfo[choice].mTotalSeat[chTime][(i, j)]=1

                            # 예매가 완료되고나면 상영영화이름, 상영관, 예매좌석수(어른,청소년,어린이 구분), 예매좌석번호, 영화상영시간
                            # 등을 정보를 띄워주는 것이 좋을 것 같음.

                        else:
                            print " >> 초기화면으로 돌아갑니다. 감사합니다."


                        #for i in range(len(mInfo[]))



    # 상영시간에 따른 좌석 예매 현황만을 볼 수 있는 함수.
    def CheckTime(self, mInfo):

        if mInfo == []:
            print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""

        # else의 입장에서 for 다음에 오는 문장은 2번째에 해당하는 줄이니까 밑으로 내려줘야한다!
        else:
            print "\n- - - - 영화를 선택해주세요 - - - - "
            for i in range(0, len(mInfo)): print "        " + str(i + 1) + ". " + mInfo[i].mName
            print "- - - - - - - - - - - - - - - - - - "
            choice = raw_input("  >> ")

            if (len(choice) != 1):
                print "\n★ ★ ★ what? 초기 화면으로 갑니다 ★ ★ ★\n\n"
            else:
                choice = int(choice) - 1
                if choice < 0 or choice > (len(mInfo) - 1):
                    print "\n★ ★ ★ what? 초기 화면으로 갑니다 ★ ★ ★\n\n"
                else:
                    print "\n- - - - - " + mInfo[choice].mName + " 상영 시간 - - - - - "
                    print """\n>> 상영시간을 다음과 같은 형식으로 선택해주세요.
01시30분 영화의 좌석 예매 현황을 보고싶으시면 01:30 이라고 입력해주세요.\n\n"""
                    for i in range(len(mInfo[choice].mTime)): print "%s" % mInfo[choice].mTime[i],
                    print "\n- - - - - - - - - - - - - - - - - -"
                    chTime = raw_input("  >> ")
                    # 에러 try- catch
                    chTime = mInfo[choice].mTime.index(chTime)
                    printSeat(mInfo[choice].mTotalSeat[chTime]).PrintSeat()




    def Management(self, mInfo):

        # 영화관리 메뉴를 띄우고 종료 전까지 while문안에 가둔다!
        while True:

            print """\n- - - - - - - - - - - - - - - - - -
        1. 상영영화 추가
        2. 상영영화 수정
        3. 상영영화 삭제
        4. 메인으로 돌아가기
- - - - - - - - - - - - - - - - - -"""
            choice = raw_input("  >> ")

            # 에러도 한군데에 모을 수는 있는데.. 코드번호 부여해서.. 흠.. 괜찮으려나..
            if (len(choice) != 1):
                print "\n★ ★ ★ what? 다시 선택해 주세요 ★ ★ ★\n\n"
                continue
            else:
                choice=int(choice)
                # 생성
                # 매개변수의 갯수가 모자라면 error를 반환한다. ?> try catch 로 어뜨케.. 못하남..
                if choice==1 :
                    print "- - - - - - - - - - - - - - - - - - "
                    name=raw_input(" + name : ")
                    movie=None
                    for i in range(len(mInfo)) :
                        if mInfo[i].mName==name : movie=i

                    if movie==None :
                        number=input(" + number : ")
                        times=raw_input(" + time : ")
                        times=[times]
                        mInfo.append(MInfo(number, name, times))
                    else:
                        # 상영하고있는 영화라면 상영관번호는 받지않고 상영시간만 추가한다.
                        # 시간만 추가받고나면 정렬을 다시해준다 sort()
                        times = raw_input(" + time : ")
                        mInfo[movie].mTime.append(times)
                        mInfo[movie].mTime.sort()
                        home=mInfo[movie].mTime.index(times)
                        mInfo[movie].mTotalSeat.insert(home, mInfo[movie].mSeat.copy())

                    break


                # 수정
                # 영화목록을 띄워주고 선택하게 한다.
                # 영화에 대한 정보가 뜨고 상영관, 상영시간을 수정가능하도록 한다.
                elif choice==2 :
                    print "\n- - - - - - - - - - - - - - - - - - "
                    if len(mInfo)==0 : print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""
                    else:
                        for i in range(len(mInfo)) :
                            print " "+str(i+1)+". "+mInfo[i].mName
                        print "- - - - - - - - - - - - - - - - - - "
                        name = raw_input(" >> ")
                        if len(name)!=1 :
                            print "\n★ ★ ★ what? 다시 선택해 주세요 ★ ★ ★\n\n"
                            continue
                        else:
                            name=int(name)-1
                            # 영화정보 띄워주기 이름, 상영관, 상영시간
                            print "\n- - - - - - - - - - - - - - - - - - "
                            print """ 수정을 원하시는 시간을 선택해주세요.
영화 상영시간만 수정하실 수 있습니다.\n"""
                            print " - name : "+mInfo[name].mName
                            print " - number : "+str(mInfo[name].mRoom)
                            print " - times\n   ",
                            for i in range(len(mInfo[name].mTime)) :
                                if i%3==0 and i!=0 : print ""
                                print mInfo[name].mTime[i]+" ",
                            print "\n- - - - - - - - - - - - - - - - - - "
                            bef=raw_input(" >> 선택할 시간 : ")
                            # Try - catch 로 잡아줘야...
                            i = mInfo[name].mTime.index(bef)
                            if i+1 : mInfo[name].mTime[i]=raw_input(" >> 변경할 시간 : ")
                            else: "\n★ ★ ★ what? 다시 시도해 주세요 ★ ★ ★\n\n"
                            # 수정할것선택하게해야하자낭라나어리ㅏ 으어어어어어

                    break

                # 삭제
                # 영화목록을 띄워주고 선택하게해서 삭제한다.
                elif choice==3 :
                    if len(mInfo) == 0:
                        print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""
                    else:
                        print "\n- - - - - - - - - - - - - - - - - - "
                        for i in range(len(mInfo)):
                            print " " + str(i + 1) + ". " + mInfo[i].mName
                        print "- - - - - - - - - - - - - - - - - - "
                        name = raw_input(" >> ")
                        if len(name) != 1:
                            print "\n★ ★ ★ what? 다시 선택해 주세요 ★ ★ ★\n\n"
                            continue
                        else:
                            name = int(name) - 1
                            # pop 말고 삭제시키는건 없나? del!!!!!!
                            del mInfo[name]

                    break

                # 종료, 메인으로 돌아감
                elif choice==4 : break



    # 영화 총 수입확인 함수
    def InTotal(self, mInfo):

        if mInfo == []:
            print """\n- - - 상영중인 영화가 없습니다 - - -
죄송죄송 돌아가주세요 영화가 부족해요 티티\n\n\n"""

        else:
            print "\n- - - - 영화 총 수입 입니다 - - - -"
            result = 0
            for i in range(len(mInfo)):
                print "  \"%-10s\" ic : %10d won" %(mInfo[i].mName, mInfo[i].mTotal)
                result += mInfo[i].mTotal
            print "- - - - - - - - - - - - - - - - - -"
            print "     Total >> " + str(result)
            print "- - - - - - - - - - - - - - - - - -"