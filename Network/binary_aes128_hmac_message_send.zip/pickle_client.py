# -*- coding:utf-8 -*-

from socket import  *
from sys import exit
from data_file import *
from aes128 import *

import struct

class SocketInfo(SocketInfo) :
    HOST='127.0.0.1'

csock = socket(AF_INET, SOCK_STREAM)
csock.connect(SocketInfo.ADDR)

key = 'password123qwe'

while True:
    try:

        commend = csock.recv(SocketInfo.BUFSIZE)
        print "message : %s, %s" %(commend[:32], commend[32:])
        movie = AES256Decrypt(key, binascii.unhexlify(commend[:32]), binascii.unhexlify(commend[32:]))
        print "movie - - - - - %s" %movie[1]['key']
   
    except Exception, KeyboardInterrupt :
        "Error"
        csock.close()
        exit()