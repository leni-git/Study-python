# -*- coding:utf-8 -*-

# socket을 사용하기 위한 python module import
from socket import *
from data_file import *
from aes128 import *

import pickle, json
import struct, os

key = 'password123qwe'

page = ['name', {'key':'value'}, 3, [1, 2, 4, 5]]
with open("file.txt", "wb") as f :
    pickle.dump(page, f)

ssock=socket(AF_INET, SOCK_STREAM)
ssock.bind(SocketInfo.ADDR)
ssock.listen(5)
csock=None

try:
    while True :

        if csock is None :

            print "waiting for connection..."
            csock, addr_info = ssock.accept()


            # print "page : %s" %page

            with open("file.txt", "rb") as output_file :
                data = output_file.read()

            # print "data : %s" %data

            print "string - - - - - - - - - - - - - \n", data
            csock.send(AES256Encrypt(key, data))

            # 파일을 보낸다. 코드와 함께 영화 저장정보를 1차로 전송한다.
            print "Send data to > ", addr_info
            print ""

        else:
            pass

except Exception, KeyboardInterrupt:
    "Error"
    csock.close()