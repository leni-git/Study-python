 # -*- coding:utf-8 -*-

from socket import  *
from sys import exit
from data_file import SocketInfo

from asefile import *

key = 'password123qwe'

class SocketInfo(SocketInfo) :
    HOST='127.0.0.1'
csock=socket(AF_INET, SOCK_STREAM)
csock.connect(SocketInfo.ADDR)

while True:
    try:
        commend=raw_input(" >> ")
        m = AES256Encrypt(key, commend)
        print "m : %s" %m
        csock.send(m)
        print "waiting for response..."

        command=csock.recv(SocketInfo.BUFSIZE)
        command=command.split(" #")
        server_message = AES256Decrypt(key, binascii.unhexlify(command[0]), binascii.unhexlify(command[1]))
        print server_message

    except Exception, KeyboardInterrupt :
        print "Error "
        csock.close()

    print "connect is success"
