 # -*- coding:utf-8 -*-

# socket을 사용하기 위한 python module import
from socket import *
from data_file import *

from asefile import *


ssock=socket(AF_INET, SOCK_STREAM)
ssock.bind(SocketInfo.ADDR)
ssock.listen(5)
csock=None

key = 'password123qwe'


while True :
    try :
        if csock is None :
            print "waiting for connection..."
            csock, addr_info = ssock.accept()
            print "got connection from", addr_info
        else:
            print "waiting for response..."
            commend=csock.recv(SocketInfo.BUFSIZE)
            print "send commend : %s" %commend
            commend = commend.split(" #")
            print "commend size : %d" %len(commend)
            client_message =  AES256Decrypt(key, binascii.unhexlify(commend[0]), binascii.unhexlify(commend[1]))
            print "accept >> %s" %client_message

            # if client_message=="hi" :
            #     csock.send(AES256Encrypt(key, 'MESSAGE: SUCCESS #id_idur'))
            # elif client_message=="exit" :
            #     csock.send("bye")
            # else:
            #     print "Last else commend : ", commend

    except KeyboardInterrupt :
        "Error"
        csock.close()