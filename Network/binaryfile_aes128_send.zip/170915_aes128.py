import struct, hashlib, time
import binascii
import os
from Crypto.Cipher import AES

AES_MODE = AES.MODE_CBC
IVEC_SIZE = 16

def decrypt_file(key, in_filename, out_filename, chunksize=24 * 1024):
    key = hashlib.sha256(key).digest()
    with open(in_filename, 'rb') as infile:
        origsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
        iv = infile.read(16)
        decryptor = AES.new(key, AES.MODE_CBC, iv)
        with open(out_filename, 'wb') as outfile:
            while True:
                chunk = infile.read(chunksize)
                if len(chunk) == 0:
                    break
                outfile.write(decryptor.decrypt(chunk))
            outfile.truncate(origsize)


def encrypt_file(key, in_filename, out_filename=None, chunksize=65536):
    print "encrypt_file start - - - - - - - - - - - -"
    key = hashlib.sha256(key).digest()
    if not out_filename:
        out_filename = in_filename + '.enc'
    iv = 'initialvector123'
    encryptor = AES.new(key, AES.MODE_CBC, iv)
    filesize = os.path.getsize(in_filename)
    with open(in_filename, 'rb') as infile:
        with open(out_filename, 'wb') as outfile:
            outfile.write(struct.pack('<Q', filesize))
            outfile.write(iv)
            while True:
                chunk = infile.read(chunksize)
                if len(chunk) == 0:
                    break
                elif len(chunk) % IVEC_SIZE != 0:
                    chunk += ' ' * (IVEC_SIZE - len(chunk) % IVEC_SIZE)
                outfile.write(encryptor.encrypt(chunk))


def make_pass():
    timekey = int(time.time())
    return str(timekey)+"leni"
