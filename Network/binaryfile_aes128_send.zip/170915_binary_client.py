# -*- coding:utf-8 -*-

from socket import  *
from sys import exit
from data_file import *
from aestest import *

import struct
import pickle

class SocketInfo(SocketInfo) :
    HOST='127.0.0.1'

FILE_LEN=0

def sendCommend(string):
    csock.send(string.encode())

def recvCommend():
    return csock.recv(SocketInfo.BUFSIZE).decode()

def recvByte():
    return csock.recv(SocketInfo.BUFSIZE)

csock = socket(AF_INET, SOCK_STREAM)
csock.connect(SocketInfo.ADDR)

while True:
    try:
        commend = recvCommend()
        print " >> server say : ", commend

        if commend=="START" :
            sendCommend("SEND_DATA")
            print "in MOVIE, wait data response - - - - - - - - - - - - - - - - - "
            FILE_SIZE = csock.recv(8)
            FILE_SIZE = struct.unpack('L', FILE_SIZE)[0]

            f = open("client_output", "wb")
            print "File open", "------------------------------------"

            while True:
                data = recvByte()
                if not data: break

                f.write(data)
                FILE_LEN += len(data)
                if FILE_LEN == int(FILE_SIZE): break

            print "close File", "------------------------------------"
            f.close()

            decrypt_file(make_pass(), in_filename='client_output', out_filename='original.txt')
            csock.send("CLIENT_START_READY")
            print "------------------------------------------------------------------------------------"

        else :
            pass

    except Exception as e :
        print "%s:%s" %(e, SocketInfo.ADDR)
        csock.close()
        exit()

    print "connect is success"



