# -*- coding: utf-8 -*-

import paho.mqtt.client as mqtt


# 클라이언트가 서버에게서 Connect 응답을 받을 때 호출 되는 콜백.
def on_connect(client, userdata, flags, rc) :
	print "Connected with result cod", str(rc)
	client.subscribe("HELLO/WORLD")

# 서버에게서 publish 메시지를 받을 때 호출 되는 콜백.
def on_message(client, userdata, msg) :
	print "\n", msg.topic, " ", str(msg.payload)


client = mqtt.Client()
client.on_connect = on_connect
client.on_message =  on_message # on_message callback set

# 네트워크 트래픽을 처리, 콜백 디스패치, 재접속 등을 수행하는 블러킹 함수.
# 멀티스레드 인터페이스나 수동 인터페이스를 위한 다른 loop* () 함수도 있음.

client.connect("test.mosquitto.org", 1883, 60) # MQTT server connect
client.loop_forever()

 
