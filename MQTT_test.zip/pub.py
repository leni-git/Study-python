# -*- coding: utf-8 -*-

import paho.mqtt.client as mqtt


mqttc = mqtt.Client("python_pub") # MQTT client object creat
mqttc.connect("test.mosquitto.org", 1883) # MQTT server connect
mqttc.publish("HELLO/WORLD", "hello world!!!!!!!!!!!!!!!!!!!!!!!!!!!!") # message send
mqttc.loop(2) # timeout = 2 seconds